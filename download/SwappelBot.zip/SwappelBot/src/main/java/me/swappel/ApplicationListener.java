package me.swappel;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.awt.*;
import java.util.Collection;

public class ApplicationListener extends ListenerAdapter {
    @Override
    public void onMessageReceived(MessageReceivedEvent e){

        if (e.getChannel().getId().equalsIgnoreCase("739964925895639161")){
            if (!e.getAuthor().isBot()){

                e.getChannel().sendMessage("Deine Application wurde zum Teeam gesandt!").queue();

                String message = e.getMessage().getContentDisplay();

                e.getJDA().getTextChannelById("739965007214936114").sendMessage(new EmbedBuilder()
                .setTitle("Application von " + e.getAuthor().getName())
                .setDescription(message)
                .setColor(Color.BLUE)
                .setFooter("Application Bot | Developer: Swappel")
                .build()).queue();

            }
        }

    }
}
