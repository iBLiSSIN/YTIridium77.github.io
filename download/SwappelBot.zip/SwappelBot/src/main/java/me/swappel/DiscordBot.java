package me.swappel;

import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.sharding.DefaultShardManagerBuilder;
import net.dv8tion.jda.api.sharding.ShardManager;

import javax.security.auth.login.LoginException;
import java.io.*;
import java.util.Date;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;

public class DiscordBot {

    public static DiscordBot INSTANCE;
    public ShardManager shardMan;

    public static void main(String[] args) throws LoginException, IllegalArgumentException {
        try {
            new DiscordBot();
        } catch (LoginException | IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    public DiscordBot() throws LoginException, IllegalArgumentException {
        INSTANCE = this;

        DefaultShardManagerBuilder builder = new DefaultShardManagerBuilder();
        builder.setToken("dein token!");

        builder.addEventListeners(new ApplicationListener());

        builder.setStatus(OnlineStatus.ONLINE);
        builder.setActivity(Activity.watching("Applications"));


        shardMan = builder.build();
        System.out.println("Bot Online");
    }

}
